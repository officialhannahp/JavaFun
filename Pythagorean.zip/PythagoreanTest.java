public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean iD = new Pythagorean();
        double hypotenuse = iD.calculateHypotenuse(3,6);
        System.out.println(hypotenuse);
    }
}